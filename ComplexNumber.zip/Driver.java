package labManual5;

/**
 * This Program is Design To Person all Complex Number Operations
 * Which we can do like (ADD,Subtract,divide,multiple,trignometric functions,conjugate etc)
 * 
 * @author Muhammad Nouman Butt
 * @version 1.0
 * @since March 17-2021
 */
import javax.swing.*;

public class Driver {

	 /**
	   * This Method is used to View the Menu Available and will validate tha
	   * entered option is available in menu.
	   * 
	   * @param Nothing
	   * @return String The value seleted by user
	   */
	
    static int main_menu()
    {
        int option1 = -1;
        while(true)
        {
            try
            {
                String option = JOptionPane.showInputDialog("Welcome to the Complex Number Calculator" + "\n\n" +
                        "Press 1 to Add Complex Numbers" + "\n" +
                        "Press 2 to Subtract Complex Numbers" + "\n" +
                        "Press 3 to multiple Complex Numbers" + "\n" +
                        "Press 4 To divide Complex Numbers" + "\n" +
                        "Press 5 To find Sine of Complex Number" + "\n" +
                        "Press 6 To find Cosine of Complex Number" + "\n" +
                        "Press 7 to find Tangent of Complex Number" + "\n" +
                        "Press 8 to find Conjugate of Complex Number" + "\n" +
                        "Press 9 to find Absolute Value of Complex Number" + "\n" +
                        "Press 0 to Close the Calculator" + "\n" );
                option1 = Integer.parseInt(option);
                if (option1 >= 0 && option1 <= 9) {
                    return option1;
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"This Option Isn't Available. Please Choose Again" + "\n" +
                                                                              "Press OK to Return To Menu Again.","In-valid Choice",2);
                }
            }catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null,"InValid Input Please Enter Again"+ "\n" +
                                                                          "Press OK to Return To Menu Again.","In-valid Input",2);
            }
        }

    }

    /**
     * This Is the Main Method which is used all the manipulations and Fucntions Calling
     * 
     * @return Nothing
     * @param args the command line arguments
     */
    
    public static void main(String[] args)
    {
        ComplexNumber ComNum1 = new ComplexNumber();
        ComplexNumber ComNum2 = new ComplexNumber();
        ComplexNumber tempe = new ComplexNumber();

        String num1 = "";
        String num2 = "";
        double r1 = 0.0, r2 = 0.0;
        double m1 = 0.0, m2 = 0.0;

        int menu_option = -1;

        do {
        	
        	menu_option = main_menu();
            switch(menu_option)
            {
                case 1:
                         num1 = JOptionPane.showInputDialog("Enter First Complex Number: ");
                         num2 = JOptionPane.showInputDialog("Enter Second Complex Number: ");
                         if (ComplexNumber.ValidateComNum(num1) && ComplexNumber.ValidateComNum(num2))
                         {
                             r1 = ComplexNumber.getReal(num1);
                             m1 = ComplexNumber.getImaginary(num1);
                             r2 = ComplexNumber.getReal(num2);
                             m2 = ComplexNumber.getImaginary(num2);
                             ComNum1 = new ComplexNumber(r1,m1);
                             ComNum2 = new ComplexNumber(r2,m2);
                             tempe = ComNum1.add(ComNum2);
                             if( tempe.getImaginary() >= 0 )
                             {
                            	 JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Addition Result",1);
                             }
                             else
                             {
                            	 JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Addition Result",1);
                             }
                         }
                         else
                         {
                             JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                     "Press OK to Return To Menu Again.","In-valid",2);
                         }
                       break;
                case 2:
                       num1 = JOptionPane.showInputDialog("Enter First Complex Number: ");
                       num2 = JOptionPane.showInputDialog("Enter Second Complex Number: ");
                       if (ComplexNumber.ValidateComNum(num1) && ComplexNumber.ValidateComNum(num2))
                       {
                           r1 = ComplexNumber.getReal(num1);
                           m1 = ComplexNumber.getImaginary(num1);
                           r2 = ComplexNumber.getReal(num2);
                           m2 = ComplexNumber.getImaginary(num2);
                           ComNum1 = new ComplexNumber(r1,m1);
                           ComNum2 = new ComplexNumber(r2,m2);
                           tempe = ComNum1.subtract(ComNum2);
                           if( tempe.getImaginary() >= 0 )
                           {
                        	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Subtraction Result",1);
                           }
                           else
                           {
                        	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Subtraction Result",1);
                           }
                       }
                       else
                       {
                           JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                   "Press OK to Return To Menu Again.","In-valid",2);
                       }

                    break;
                case 3:
                    num1 = JOptionPane.showInputDialog("Enter First Complex Number: ");
                    num2 = JOptionPane.showInputDialog("Enter Second Complex Number: ");
                    if (ComplexNumber.ValidateComNum(num1) && ComplexNumber.ValidateComNum(num2)) {
                        r1 = ComplexNumber.getReal(num1);
                        m1 = ComplexNumber.getImaginary(num1);
                        r2 = ComplexNumber.getReal(num2);
                        m2 = ComplexNumber.getImaginary(num2);
                        ComNum1 = new ComplexNumber(r1,m1);
                        ComNum2 = new ComplexNumber(r2,m2);
                        tempe = ComNum1.multiple(ComNum2);
                        if( tempe.getImaginary() >= 0 )
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Multiplication Result",1);
                        }
                        else
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Multiplication Result",1);
                        }
                        }
                       else
                       {
                         JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                                                                    "Press OK to Return To Menu Again.","In-valid",2);
                        }

                    break;
                case 4:

                    num1 = JOptionPane.showInputDialog("Enter First Complex Number: ");
                    num2 = JOptionPane.showInputDialog("Enter Second Complex Number: ");
                    if (ComplexNumber.ValidateComNum(num1) && ComplexNumber.ValidateComNum(num2)) {
                        r1 = ComplexNumber.getReal(num1);
                        m1 = ComplexNumber.getImaginary(num1);
                        r2 = ComplexNumber.getReal(num2);
                        m2 = ComplexNumber.getImaginary(num2);
                        ComNum1 = new ComplexNumber(r1,m1);
                        ComNum2 = new ComplexNumber(r2,m2);
                        tempe = ComNum1.divide(ComNum2);
                        if( tempe.getImaginary() >= 0 )
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Division Result",1);
                        }
                        else
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Division Result",1);
                        }

                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                    }
                    break;
                case 5:
                	num1 = JOptionPane.showInputDialog("Enter Complex Number to find Sine: ");
                    if (ComplexNumber.ValidateComNum(num1)) 
                    {
                        r1 = ComplexNumber.getReal(num1);
                        m1 = ComplexNumber.getImaginary(num1);
                        ComNum1 = new ComplexNumber(r1,m1);
                        tempe = ComNum1.sine();
                        if( tempe.getImaginary() >= 0 )
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Sine Result",1);
                        }
                        else
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Sine Result",1);
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                    }
                	

                    break;
                case 6:
                	num1 = JOptionPane.showInputDialog("Enter Complex Number to find Cosine: ");
                    if (ComplexNumber.ValidateComNum(num1))
                    {
                        r1 = ComplexNumber.getReal(num1);
                        m1 = ComplexNumber.getImaginary(num1);
                        ComNum1 = new ComplexNumber(r1,m1);
                        tempe = ComNum1.cosine();
                        if( tempe.getImaginary() >= 0 )
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "-" + tempe.getImaginary() + "i'","Cosine Result",1);
                        }
                        else
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + " " + tempe.getImaginary() + "i'","Cosine Result",1);
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                    }

                    break;
                case 7:
                	num1 = JOptionPane.showInputDialog("Enter Complex Number to find Tangent: ");
                    if (ComplexNumber.ValidateComNum(num1))
                    {
                        r1 = ComplexNumber.getReal(num1);
                        m1 = ComplexNumber.getImaginary(num1);
                        ComNum1 = new ComplexNumber(r1,m1);
                        tempe = ComNum1.tangent();
                        if( tempe.getImaginary() >= 0 )
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Tangent Result",1);
                        }
                        else
                        {
                     	   JOptionPane.showMessageDialog(null,"Complex Number is:  '" + tempe.getReal() + "" + tempe.getImaginary() + "i'","Tangent Result",1);
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                    }

                    break;
                case 8:

                	num1 = JOptionPane.showInputDialog("Enter Complex Number to find Conjugate: ");
                	if(ComplexNumber.ValidateComNum(num1))
                	{
                		 r1 = ComplexNumber.getReal(num1);
                         m1 = ComplexNumber.getImaginary(num1);
                         ComNum1 = new ComplexNumber(r1,m1);
                         tempe = ComNum1.conjugate();
                         if( tempe.getImaginary() >= 0 )
                         {
                      	   JOptionPane.showMessageDialog(null,"Complex Conjugate is:  '" + tempe.getReal() + "+" + tempe.getImaginary() + "i'","Conjugate Result",1);
                         }
                         else
                         {
                      	   JOptionPane.showMessageDialog(null,"Complex Conjugate is:  '" + tempe.getReal() + "" + tempe.getImaginary() + "i'","Conjugate Result",1);
                         }
                	}
                	else
                	{
                		JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                	}
                	
                    break;
                case 9:
                	num1 = JOptionPane.showInputDialog("Enter Complex Number to find Absolute: ");
                	if(ComplexNumber.ValidateComNum(num1))
                	{
                		 r1 = ComplexNumber.getReal(num1);
                         m1 = ComplexNumber.getImaginary(num1);
                         ComNum1 = new ComplexNumber(r1,m1);
                        double abso = ComNum1.absolute();
                         
                      	   JOptionPane.showMessageDialog(null,"Absolute of Complex Number is = " + abso,"Absolute Result",1);
                        
                	}
                	else
                	{
                		JOptionPane.showMessageDialog(null,"Entered Numbers Are not valid Complex Numbers" + "\n" +
                                "Press OK to Return To Menu Again.","In-valid",2);
                	}

                    break;

                case 0:

                    break;
                default:
                    JOptionPane.showMessageDialog(null,"In-Valid Input Please Enter Again"+ "\n" +
                                                                             "Press OK to Return To Menu Again.","In-valid Input",2);

            }

        	
        }while(menu_option != 0);
 
    }
}
