package labManual5;


import java.lang.Math;

/**
 * This is the Sub Class of Driver Class and is used to
 * Store Complex NUmbers and for all the Manipulations
 * 
 * @author Muhammad Nouman Butt
 * @version 1.0
 * @since March 17-2021
 */

public class ComplexNumber {

    private double real;
    private double imaginary;


    /**
     * This Is Constructor used to initialize Complex Numbers option without Parameters 
     * 
     * @param Nothing
     * @return nothing
     */
    ComplexNumber()
    {
        this.imaginary = 0.0;
        this.real = 0.0;
    }
    
    /**
     * This Is Constructor used to initialize Car option with Parameters 
     * 
     * @param double real
     * @param double imaginary
     * @return nothing
     */
    ComplexNumber( double real,double imaginary )
    {
        this.real = real;
        this.imaginary = imaginary;
    }
    
    /**
     * This Is Method used to access Imaginar Private Attribute 
     * 
     * @param Nothing
     * @return Imaginary private Field
     */

    public double getImaginary() {
        return imaginary;
    }

    /**
     * This Is Method used to access Real Private Attribute 
     * 
     * @param Nothing
     * @return real private Field
     */
    public double getReal() {
        return real;
    }

    /**
     * This Is Method used to set Imaginary Private Attribute 
     * 
     * @param imaginary passed from Driver.
     * @return nothing
     */
    public void setImaginary(double imaginary) {
        this.imaginary = imaginary;
    }

    /**
     * This Is Method used to set Real Private Attribute 
     * 
     * @param real passed from Driver.
     * @return nothing
     */
    public void setReal(double real) {
        this.real = real;
    }

    /**
     * This Is Method Perform Addition On Two Complex Numbers Object
     * One through which functions is called and other is passed. 
     * 
     * @param ComplexNumber c2(object)
     * @return ComplexNumber temp(Object)
     */
    public ComplexNumber add(ComplexNumber c2)
    {
        ComplexNumber temp = new ComplexNumber();
        double reall = (this.getReal() + c2.getReal());
        double ima = (this.getImaginary() + c2.getImaginary());
        temp.setReal(reall);
        temp.setImaginary(ima);
        return temp;
    }

    /**
     * This Is Method Perform Subtraction On Two Complex Numbers Object
     * One through which functions is called and other is passed. 
     * 
     * @param ComplexNumber c2(object)
     * @return ComplexNumber temp(Object)
     */
    public ComplexNumber subtract(ComplexNumber c2)
    {
        ComplexNumber temp = new ComplexNumber();
        double reall = (this.getReal() - c2.getReal());
        double ima = (this.getImaginary() - c2.getImaginary());
        temp.setReal(reall);
        
        temp.setImaginary(ima);
       
        return temp;
    }
    
    /**
     * This Is Method Perform Multiplication On Two Complex Numbers Object
     * One through which functions is called and other is passed. 
     * 
     * @param ComplexNumber c2(object)
     * @return ComplexNumber temp(Object)
     */
    public ComplexNumber multiple(ComplexNumber c2)
    {
        ComplexNumber temp = new ComplexNumber();
        double reall = ( ( this.getReal() * c2.getReal()) + ( -1 * ( this.getImaginary() * c2.getImaginary() ) ));
        double ima   = (( this.getReal() * c2.getImaginary() ) + ( this.getImaginary() * c2.getReal()));
        temp.setReal(reall);
        
        temp.setImaginary(ima);
       
        return temp;
    }
    
    /**
     * This Is Method find the absolute of the Complex Number
     * throught which function is called 
     * 
     * @param Nothing
     * @return double absolute
     */
    public double absolute()
    {
    	double absolute = 0;
    	double reall = this.getReal();
    	double imag = this.getImaginary();
    	absolute = Math.sqrt((Math.pow(reall, 2) + Math.pow(imag, 2))); 
    	
    	return absolute;
    }
    
    /**
     * This Is Method find the conjugate of the Complex Number
     * throught which function is called
     *  
     * @param nothing
     * @return ComplexNumber temp(Object)
     */
    public ComplexNumber conjugate()
    {
    	ComplexNumber temp = new ComplexNumber();
    	double reall = this.getReal();
    	double ima = -(this.getImaginary());
    	temp.setReal(reall);
    	temp.setImaginary(ima);
    	
    	return temp;
    }
    
    /**
     * This Is Method Perform Divide On Two Complex Numbers Object
     * One through which functions is called and other is passed. 
     * 
     * @param ComplexNumber c2(object)
     * @return ComplexNumber temp(Object)
     */
    public ComplexNumber divide(ComplexNumber c2)
    {
    	ComplexNumber temp = new ComplexNumber();
    	ComplexNumber returnn = new ComplexNumber();

    	temp = c2.conjugate();
    	double down = Math.pow(c2.getReal(), 2) + Math.pow(c2.getImaginary(), 2);
    	double upReal =  ( ( this.getReal() * temp.getReal()) + ( -1 * ( this.getImaginary() * temp.getImaginary() ) ));
    	double upImagi = (( this.getReal() * temp.getImaginary() ) + ( this.getImaginary() * temp.getReal()));
    	double reall = upReal/down;
    	double ima = upImagi/down;
    	
    	returnn.setReal(reall);
    	returnn.setImaginary(ima);
    	
    	return returnn;
    }

    
    /**
     * This Method is used to Find Hyperbolic cos of a variable 
     * 
     * @param double x
     * @return double coshh. 
     */
    static double cosh(double x) {
        
    	double coshh = 0.0;
    	coshh = (Math.exp(x) + Math.exp(-x))/2;
    	return coshh;
   }

    
    /**
     * This Method is used to Find Hyperbolic sine of a variable 
     * 
     * @param double x
     * @return double sinhh. 
     */
    static double sinh(double x) {
        
    	double sinhh = 0.0;
    	sinhh = (Math.exp(x) - Math.exp(-x))/2;
    	return sinhh;
   }
   
    
    /**
     * This Method is used to Find sine of Complex Number 
     * Through which this Function is Called.
     * 
     * @param nothing
     * @return ComplexNumber tempe. 
     */
  public ComplexNumber sine()
  {
        double x = 0.0;
        double y = 0.0;
        double reall = 0.0;
        double ima = 0.0;
        ComplexNumber tempe = new ComplexNumber();
        x = this.getReal();
        y = this.getImaginary();
        reall = Math.sin(x) * cosh(y);
        ima = Math.cos(x) * sinh(y);
        tempe.setReal(reall);
    	tempe.setImaginary(ima);
        return tempe;
      }
  
  /**
   * This Method is used to Find Cosine of Complex Number 
   * Through which this Funtion is Called.
   * 
   * @param nothing
   * @return ComplexNumber tempe. 
   */
  public ComplexNumber cosine()
  {
        double x = 0.0;
        double y = 0.0;
        double reall = 0.0;
        double ima = 0.0;
        ComplexNumber tempe = new ComplexNumber();
        x = this.getReal();
        y = this.getImaginary();
        reall = Math.cos(x) * cosh(y);
        ima = Math.sin(x) * sinh(y);
        tempe.setReal(reall);
    	tempe.setImaginary(ima);
        return tempe;
      }
  
  /**
   * This Method is used to Find Tangent of Complex Number 
   * Through which this Funtion is Called.
   * 
   * @param nothing
   * @return ComplexNumber tan. 
   */
  public ComplexNumber tangent()
  {
	  ComplexNumber sin = new ComplexNumber();
	  ComplexNumber cos = new ComplexNumber();
	  ComplexNumber tan = new ComplexNumber();
	 
	  sin = this.sine();
	 // System.out.println(sin.getReal() +"  "+ sin.getImaginary());
	  cos = this.cosine();
	 // System.out.println(cos.getReal() + "  "+ cos.getImaginary());

	  tan = sin.divide(cos);
	  return tan;
	  
  }
  
  /**
   * This Is Method Validate the Complex NUmber String to it. 
   * 
   * @param String complexnum
   * @return Boolean 
   */
  public
    static boolean ValidateComNum(String ComplexNum)
    {
        boolean flag = false;
        int z,j;
        int size = ComplexNum.length();

        if (ComplexNum.charAt(size-1) == 'i')
        {
            flag = true;
        }

        if (flag == true)
        {
            for (byte i=0; i < size ; i++)
            {
                if ( ComplexNum.charAt(i) == '+' || ComplexNum.charAt(i) == '-' )
                {
                    flag = true;
                    z = i;
                    break;
                }
                else
                {
                    flag = false;
                }
            }

            if ( flag == true )
            {
                for (byte i = 0; i < size-1 ; i++)
                {
                   if ( !((ComplexNum.charAt(i) >= 'A' && ComplexNum.charAt(i) <= 'Z') || (ComplexNum.charAt(i) >= 'a' && ComplexNum.charAt(i) <= 'z')) )
                   {
                        flag = true;
                   }
                   else
                       {
                       flag = false;
                       break;
                   }
                }
            }


        }

        return flag;
    }

  
  /**
   * This Is Method to find real part from complex number.
   *  
   * @param String num
   * @return double real
   */
     static double getReal(String num)
     {
         String a = "";
         
         
         for (byte i = 0; i < num.length() ; i++)
         {
             if (num.charAt(i) == '+' || num.charAt(i) == '-')
           {
               break;
           }
           else
           {
               a = a + num.charAt(i);
           }
         }
         double real = Double.parseDouble(a);
         return real;
     }
     
     /**
      * This Is Method to find imaginary part from complex number.
      *  
      * @param String num
      * @return double imaginary
      */
     static double getImaginary(String num)
     {
         String a = "";
         short k = -1;
         for (short i = 0; i< num.length() ; i++)
         {
             if (num.charAt(i) == '+' || num.charAt(i) == '-')
             {
                 k =i;
                 break;
             }
         }
         for (short i = k; i < num.length()-1 ; i++)
         {
             a = a + num.charAt(i);
         }
         double imaginary = Double.parseDouble(a);
         return imaginary;
     }


}
