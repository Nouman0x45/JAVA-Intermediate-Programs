/**
 * Auto Generated Java Class.
 */
import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;

public class Program {
  
static boolean saveDMC(Student s1)
  {
    try
    {
      FileWriter fw = new FileWriter("dmc.txt");
      CourseResult courses = new CourseResult();
      ///////////////////////////////////////////
 CourseResult DMC = new CourseResult();
               String gradee = "";
               Double ggpa = 0.0;
               Double ccgpa = 0.0;
               int crdhour = 0;
               String gpaa;
               fw.write("Name: " + s1.StudentName + "      Degree:  "+ s1.Degree + " " + getDiscipline(s1.RegistrationNumber) + "\n");
               fw.write("Registrataion Number: " + s1.RegistrationNumber + "\n");
               fw.write("Session: "+getSession(s1.RegistrationNumber) + "\n\n");
               for(int i = 0 ; i < 8 ; i++ )
               {
                 for(int k=0; k< s1.list.size(); k++)
                 {
                   courses = new CourseResult();
                   courses = s1.list.get(k);
                   int seme = courses.semester;
                  if (seme == (1+i))
                   {
                     
                     fw.write("Semester " + (i+1) + " :\n");
                     fw.write("ID       "+"Name              " + "CH    "+ "Marks     "+ "Grades     " + "\n"); 
                     for(int j=0; j<s1.list.size() ;j++)
                     {
                        DMC = new CourseResult();
                        DMC = s1.list.get(j);
                        ggpa = getSemesterGPA(seme,s1.list);
                        crdhour = getSemesterCreditHours(seme,s1.list);
                        ggpa = ggpa / crdhour;
                        gradee = getGrade(DMC.marks);
                        if(seme == DMC.semester)
                        {
                          fw.write(DMC.CourseId + "    "+DMC.CourseTitle + "            "+ Integer.toString(DMC.CreditHours) + "       " + Integer.toString(DMC.marks) + "       " +gradee + "\n"); 
                        }
                     }
                     fw.write("SGPA  " + ggpa + "\n");
                     break;
                   }
                 }
                 
               }
                 ccgpa = getCGPA(s1.list);
                 fw.write("CGPA   "+ccgpa+ "\n");
      //////////////////////////////////////////
      fw.flush();
      fw.close();
    }
    catch(Exception ex)
    {
      System.out.println("an Error is occoured");
    }
    return true;
  }
  static Student readData()
 { 
    Student s2 = new Student();
     s2.list = new ArrayList<CourseResult>();
      CourseResult coursee = new CourseResult();
      
    try{
      FileReader fr = new FileReader("studentdata.txt");
      BufferedReader br = new BufferedReader(fr);
      String line = br.readLine();
      String arr[] = line.split(",");
      //now
      s2.StudentName = arr[0];
      s2.RegistrationNumber = arr[1];
      s2.Degree = arr[2];
      //line = br.readLine();
      line = br.readLine();
      while(line !=  "")
      {
        coursee = new CourseResult();
        String arr1[] = line.split(",");
             //System.out.println("end");
        coursee.CourseId = arr1[0];
         System.out.println(coursee.CourseId);
        coursee.CourseTitle = arr1[1];
        String aa = arr1[2];
        int a = Integer.parseInt(aa);
        coursee.CreditHours = a;
        int mark = Integer.parseInt(arr1[3]);
        coursee.marks = mark;
        int sem = Integer.parseInt(arr1[4]);
        coursee.semester = sem;
        s2.list.add(coursee);
        line = br.readLine();
      }
      fr.close();
      br.close();
    }
   catch(Exception e)
    {
     
    }
  return s2;  
  }
  static boolean saveData(Student s1)
  {
    boolean flag = false;
    try{
      CourseResult course = new CourseResult();
      FileWriter fw = new FileWriter("studentdata.txt");
      fw.write(s1.StudentName + "," +s1.RegistrationNumber + "," + s1.Degree + "\n");
      int size = s1.list.size();
      for(int i=0; i< size ;i++)
      {
        course = new CourseResult();
        course = s1.list.get(i);
        fw.write(course.CourseId + "," + course.CourseTitle + "," + course.CreditHours + "," + course.marks + "," + course.semester + "\n");
       flag = true;
      }
      fw.flush();
      fw.close();
      
    }
    catch(Exception ex)
    {
      System.out.println("An Error has Occoured");
      flag = false;
    }
    return flag;
  }
  
  static String main_menu()
  {
    boolean flag = true;
    String input = "";
    do
    {
      try
    {
        flag = true;
        
        input = JOptionPane.showInputDialog("Choose the following option: " + "\n" + 
                                        "Choose 1 to set basic information of student" + "\n" +
                                        "Choose 2 to add new course in Grade Book " + "\n" +
                                        "Choose 3 to edit a course" + "\n" +
                                        "Choose 4 to delete a course" + "\n" +
                                        "Choose 5 to view all courses" + "\n" +
                                        "Choose 6 to view CGPA" + "\n" + 
                                        "Choose 7 to view detailed marks certificate" + "\n" +
                                        "Choose 8 to save data" + "\n" +
                                        "Choose 0 to exit" + "\n");
    
    }
    catch(Exception ex)
    {
      flag = false;
      JOptionPane.showMessageDialog(null,"Wrong Input.Please Enter Again","Error",2);
    }
    }while(!flag);
    
    
    return input;
  } // ending of main_menu
  
  static boolean validatestuinfo(String stu_info)
  {
    boolean final_flag = false;
    String arr[] = stu_info.split(",");
    
    boolean flag2 = validateStudentName(arr[0]);
    boolean flag1 = validateRegistartionNumber(arr[1]);
    boolean flag3 = validateDegree(arr[2]);
    if(flag1 ==  true && flag2 == true && flag3 == true)
    {
      final_flag = true;
    }
    return final_flag;
    
  }
  
  static boolean validateCourse (CourseResult course)
  {
    boolean flag_final = false;
    boolean flag1 = validateSemester(course.semester);
    boolean flag2 = validateMarks(course.marks);
    boolean flag3 = validateCreditHours(course.CreditHours);
    boolean flag4 = validateCourseTitle(course.CourseTitle);
    boolean flag5 = validateCourseId(course.CourseId);
    if( flag1 == true && flag2 == true && flag3 == true && flag4 == true && flag5 == true )
    {
      flag_final = true;
    }
    return flag_final;
  }
  
  static boolean validateSemester(int semester)
  {
    boolean flag = true;
    if (!(semester >= 1 && semester <= 8))
    {
      flag = false;
    }
    
    return flag;
  }
  
  static boolean validateMarks(int marks)
  {
    boolean flag = true;
    if (!(marks >= 0 && marks <= 100))
    {
      flag = false;
    }
    
    return flag;
  }
  
  static boolean validateCreditHours(int creditHours)
  {
    boolean flag = true;
    if (!(creditHours >= 1 && creditHours <= 3))
    {
      flag = false;
    }
    
    return flag;
  }
  
  static boolean validateCourseTitle(String courseTitle)
  {
    boolean flag = true;
    
    for (int i = 0; i < courseTitle.length() ; i++)
    {
      if (!((courseTitle.charAt(i) >= 'a' && courseTitle.charAt(i) <= 'z') || (courseTitle.charAt(i) >= 'A' && courseTitle.charAt(i) <= 'Z')  || (courseTitle.charAt(i) == ' ')))
      { 
        flag = false;
      }
      
    }
    return flag;
  }
  static boolean validateCourseId(String courseId)
  {
    int x = courseId.length();
    boolean flag = true;
    if (x == 5)
    {
      
      for (int i = 0; i < 2; i++)
      {
        if (!(courseId.charAt(i) >= 'A' && courseId.charAt(i) <= 'Z'))
        {
          flag = false;
          break;
        }
      }
      
      for (int i = 2; i < 5 && flag; i++)
      {
        if (!(courseId.charAt(i) >= '0' && courseId.charAt(i) <= '9'))
        {
          flag = false;
          break;
        }
      }
    }
    else if( x == 6)
    {
      if( courseId.charAt(5) == 'L')
      {
        for (int i = 0; i < 2; i++)
        {
          if (!(courseId.charAt(i) >= 'A' && courseId.charAt(i) <= 'Z'))
          {
            flag = false;
            break;
          }
        }
        
        for (int i = 2; i < 5 && flag; i++)
        {
          if (!(courseId.charAt(i) >= '0' && courseId.charAt(i) <= '9'))
          {
            flag = false;
            break;
          }
        }
      }
      
    }
    
    return flag;
  }
  
  static boolean validateDegree(String degree)
  {
    boolean flag = false;
    for(int i=0; i<degree.length();i++)
    {
      if( degree.equals("MS") || degree.equals("ms")  || degree.equals("BS") || degree.equals("bs")  || degree.equals("be") || degree.equals("BE") )
      {
        flag = true;
      }
      else
      {
        flag = false;
      }
    }
    
    return flag;
  } // ending degree
  static boolean validateRegistartionNumber(String regNo)
  {
    int x = regNo.length();
    boolean flag_reg = false;
    if( x == 11 )
    {
      if(regNo.charAt(0) == '2' && regNo.charAt(1) == '0'  && regNo.charAt(5)=='C' && regNo.charAt(4) == '-' && regNo.charAt(7) == '-' )
      {
        flag_reg =true;
        
        for ( int n = 2; n < 4 ; n++)
        {
          if( regNo.charAt(n) >= '0' && regNo.charAt(n) <= '9' )
          {
            flag_reg = true;
          }
          else
          {
            flag_reg = false;
            break;
          } 
        }
        if( regNo.charAt(6) >= 'A' && regNo.charAt(6)<= 'Z')
        {
          flag_reg= true;
        }
        else
        {
          flag_reg= false;
        }
        
        for (int j = 8; j < 11; j++)
        {
          if( regNo.charAt(j) >= '0' && regNo.charAt(j) <= '9')
          {
            flag_reg = true;
          }
          else
          {
            flag_reg = false;
          }   
        }
      }
      else
      {
        flag_reg = false;
      }
    }
    
    return flag_reg;
  } //ending regno
  
  static boolean validateStudentName(String name)
  {
    boolean flag = true;
    
    for (int i = 0; i < name.length() ; i++)
    {
      if (!((name.charAt(i) >= 'a' && name.charAt(i) <= 'z') || (name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')  || (name.charAt(i) == ' ')))
      { 
        flag = false;
      }
      
    }
    
    return flag;
  } // ending stuent name
  
  static String basic_stud_info()
  {
    String input;
    input = JOptionPane.showInputDialog("Please enter the basic information in the following format" + "\n" +
                                        "Name, Registration Number, Degree" , "Student Basic Input");
    return input;
  } // ending of input stu info
  
  static String add_new_course()
  {
    String input;
    input = JOptionPane.showInputDialog("Please enter the course information in the following format" + "\n" +
                                        "Course ID, Course Title, Credit Hours, Semester , Marks" );
    return input;
  } 
  
  static void add_stu(Student s1,String stu_info)
  {
    String arr[] = stu_info.split(",");
    s1.StudentName = arr[0];
    s1.RegistrationNumber = arr[1];
    s1.Degree = arr[2];
    
  }
  
  static boolean store_course(Student s1,CourseResult course,String course_info)
  {
    boolean flag1 = false;
    String arr[] = course_info.split(",");
    //now
    course.CourseId = arr[0];
    course.CourseTitle = arr[1];
    int crehours = Integer.parseInt(arr[2]);
    course.CreditHours = crehours;
    int sem = Integer.parseInt(arr[3]);
    course.semester = sem;
    int mark = Integer.parseInt(arr[4]);
    course.marks = mark;
    flag1 = validateCourse (course);
    if(flag1 == true)
    {
      return true;
    }
    else
    {
      return false;
    }
    
  }
  static boolean add_course(Student s1,CourseResult course)
  {
    boolean flag3 = true;
    CourseResult cc = new CourseResult();
    for(int i = 0;i< s1.list.size();i++)
    {
      cc = (CourseResult)s1.list.get(i);
      String hhb = cc.CourseId;
      if (course.CourseId.equals(hhb))
      {
        
        flag3 = false;
        break;
      }
    }
    if( flag3 == true)
    {
      s1.list.add(course);
      System.out.println("Added");
    }
    return flag3;
  }
  
  static boolean update_course(Student s1,CourseResult course,String input)
  {
    boolean flag3 = true;
    CourseResult cc = new CourseResult();
    for(int i = 0;i< s1.list.size();i++)
    {
      cc = (CourseResult)s1.list.get(i);
      String hhb = cc.CourseId;
      if (course.CourseId.equals(hhb))
      {
        flag3 = false;
        break;
      }
    }    
    return flag3;
  }
  static void update_cours(Student s1,CourseResult course,String input)
  {
    CourseResult cc = new CourseResult();
    for(int i = 0;i< s1.list.size();i++)
    {
      cc = (CourseResult)s1.list.get(i);
      String hhb = cc.CourseId;
      if (input.equals(hhb))
      {
        s1.list.set(i,course);
        break;
      }
    }
  }
  
  static boolean update_check(Student s1,CourseResult course,String input)
  {
    for(int i = 0;i< s1.list.size();i++)
    {
      CourseResult c = (CourseResult)s1.list.get(i);
      String hhb = c.CourseId;
      if (input.equals(hhb))
      {
        return true; 
      }
    }
    return false;
  }
  
  static boolean delete_course(Student s1,String input)
  {
    boolean flag3 = false;
    CourseResult cc = new CourseResult();
    for(int i = 0;i< s1.list.size();i++)
    {
      cc = (CourseResult)s1.list.get(i);
      String hhb = cc.CourseId;
      if(input.equals(hhb))
      {
        s1.list.remove(i);
        flag3 = true;
        break;
      }
    }
    return flag3;
  }
  
  static String getGrade(int marks)
  {
    String grades = "";
    if( marks >= 80)
    {
      grades = "A";
    }
    else if( marks >= 70 && marks < 80)
    {
      grades = "A-";
    }
    else if( marks >= 65 && marks < 70)
    {
      grades = "B+";
    }
    else if( marks >= 60 && marks < 65)
    {
      grades = "B-";
    }
    else if( marks >= 55 && marks < 60)
    {
      grades = "C+";
    }
    else if( marks >= 50 && marks < 55)
    {
      grades = "C";
    }
    else if( marks >= 40 && marks < 50)
    {
      grades = "D";
    }
    else if(marks < 40)
    {
      grades = "F";
    }
    return grades;
  }
  
  static double getGradePoints(String grades)
  {
    double gradepoint = 0.0;
    if (grades == "A")
    {
      gradepoint = 4.0;
    }
    else if (grades == "A-")
    {
      gradepoint = 3.7;
    }
    else if (grades == "B+")
    {
      gradepoint = 3.3;
    }
    else if (grades == "B-")
    {
      gradepoint = 3.0;
    }
    else if (grades == "C+")
    {
      gradepoint = 2.7;
    }
    else if (grades == "C-")
    {
      gradepoint = 2.3;
    }
    else if (grades == "D")
    {
      gradepoint = 1.0;
    }
    else if (grades == "F")
    {
      gradepoint = 0.0;
    }
    return gradepoint;
  }
  
//  static int getSemesters(List<CourseResult>list)
//  {
//    int sem[] = new sem
//  }
  static int getSemesterCreditHours(int semester,List<CourseResult>list)
  {
    int crdhours = 0;
    CourseResult oobjj = new CourseResult();
    for(int i=0; i < list.size();i++)
    {
      oobjj = new CourseResult();
      oobjj = list.get(i);
      if(semester == oobjj.semester)
      {
        crdhours = crdhours + oobjj.CreditHours;
      }
    }
    return crdhours;
  }
  
  
  static double getSemesterGPA(int semester,List<CourseResult>list)
  {
    Double GPA = 0.0;
    String gradw = "";
    Double grdpoint = 0.0;
    CourseResult oobjj = new CourseResult();
    int size = list.size();
      for(int i =0; i<size; i++)
    {
        oobjj = new CourseResult();
      oobjj = list.get(i);
      if(semester == oobjj.semester)
      {
        gradw = getGrade(oobjj.marks);
        grdpoint = oobjj.CreditHours * getGradePoints(gradw);
        GPA = GPA + grdpoint;
      }
    }
    return GPA;
  }
  
  static int getTotalCreditHours(List<CourseResult>list)
  {
    int Tcrdhours = 0;
    CourseResult oobjj = new CourseResult();
    for(int i=0; i < list.size();i++)
    {
      oobjj = new CourseResult();
      oobjj = list.get(i);
        Tcrdhours = Tcrdhours + oobjj.CreditHours;
    }
    return Tcrdhours;
  }
  
  static double getCGPA(List<CourseResult>list)
  {
   // Double semgpa[] = new Double[8];
   // Double semcre[] = new Double[8];
    int count = 0;
    CourseResult oobj = new CourseResult();
    double CGPA = 0.0;
    double sum_GPA = 0.0;
    int totalcrdhours = 0;
    for(int i =0; i<8 ;i++)
    {
      for(int k = 0; k < list.size(); k++)
      {
        oobj = new CourseResult();
        oobj = list.get(k);
        int sem = oobj.semester;
        if( sem == (1+i))
        {
          if(count == 0)
          {
            sum_GPA = sum_GPA + getSemesterGPA(sem,list);
            //semgpa[i] = semgpa[i] +  getSemesterGPA(sem,list);
            //semcre[i] = semcre[i] +  getSemesterCreditHours(sem,list);
            count++;
          }
        }
    }
      count = 0;
  }
     totalcrdhours = getTotalCreditHours(list);
//     for(int i=0;i<8;i++)
//     {
//       sum_GPA = sum_GPA + semgpa[i];
//     }
     CGPA = sum_GPA / totalcrdhours;
     return CGPA;
  }
  
  static String getSession(String regNo)
  {
    String arr[] = regNo.split("-");
    String session = arr[0];
    return session;
  }
  static String getDiscipline(String regNo)
  {
    String arr[] = regNo.split("-");
    String dis = arr[1];
    return dis;
  }
  
  public static void main(String[] args)
  {
    String input;
    Student s1 = new Student();
    s1.list = new ArrayList<CourseResult>();
    CourseResult course = new CourseResult();
    s1 = readData();
    String main_menu_op; 
    String stu_info , course_info;
    boolean flag = false;
    int option;
    do{
      main_menu_op = main_menu();
      option = Integer.parseInt(main_menu_op);
      switch(option){
        case 1:
          stu_info = basic_stud_info();
          flag = validatestuinfo(stu_info);
          if(flag == true)
          {
            add_stu(s1,stu_info);
            JOptionPane.showMessageDialog(null,"Student Has Been Added Successfully.");
          }
          else
          {
            JOptionPane.showMessageDialog(null,"Invalid Input.Please enter again.");
          }
          break;
        case 2:
          course_info = add_new_course();
          course = new CourseResult();
          flag = store_course(s1,course,course_info);
          if(flag == true)
          {
            flag = add_course(s1,course);
            if(flag == true)
            {
              JOptionPane.showMessageDialog(null,"Course Has Been Added Successfully.");
            }
            else
            {
              JOptionPane.showMessageDialog(null,"This Course Id is Already Registered");
            }
          }
          else
          {
            JOptionPane.showMessageDialog(null,"Invalid Inputs. Please Enter Again");
          }
          break;
        case 3:
          
          input = JOptionPane.showInputDialog("Please enter ID to update Course" );
          flag = update_check(s1,course,input);
          if(flag == true)
          {
            course_info = add_new_course();
            course = new CourseResult();
            flag = store_course(s1,course,course_info);
            if(flag == true)
            {
              flag = update_course(s1,course,input);
              if(flag == true)
              {
                update_cours(s1,course,input);
                JOptionPane.showMessageDialog(null,"Course Has Been Updated Successfully.");
              }
              else
              {
                JOptionPane.showMessageDialog(null,"This Course Id is Already Registered");
              }
            }
            else
            {
              JOptionPane.showMessageDialog(null,"Invalid Inputs. Please Enter Again");
            }
          }
          else{
            JOptionPane.showMessageDialog(null,"Entered Course Id Doesn't exist ");
          }
          break;
        case 4:
          input = JOptionPane.showInputDialog("Please enter Course ID to delete a course");
          flag = update_check(s1,course,input);
          if( flag == true)
          {
            flag = delete_course(s1,input);
            if( flag == true)
            {
              JOptionPane.showMessageDialog(null,"Course Has Been Deleted Successfully.");
            }
          }
          else
          {
            JOptionPane.showMessageDialog(null,"This Course Id Doesn't exist");
          }
          break;
        case 5:
          
          System.out.printf("%-20s  %-20s  %-10s  %-10s  %-10s", "ID","Name","CH","Marks","Grades");
          System.out.print("\n");
          for(int i=0;i<s1.list.size();i++)
          { 
            course = new CourseResult();
            course = s1.list.get(i);
            String Grades = getGrade(s1.list.get(i).marks);
            System.out.printf("%-20s  %-20s  %-10s  %-10s  %-10s",course.CourseId,course.CourseTitle,Integer.toString(course.CreditHours),Integer.toString(course.marks),Grades);
            System.out.print("\n");
          }
          break;
        case 6:
               Double cgpa = getCGPA(s1.list);
               JOptionPane.showMessageDialog(null,"Your CGPA is: " + cgpa);
               break;
        case 7:
               CourseResult DMC = new CourseResult();
               String gradee = "";
               Double ggpa = 0.0;
               Double ccgpa = 0.0;
               int crdhour = 0;
               String gpaa;
               System.out.printf("%-3s  %-20s  %-5s  %-1s  %-1s","Name:",s1.StudentName,"Degree:",s1.Degree,getDiscipline(s1.RegistrationNumber));
               System.out.print("\n");
               System.out.printf("%-15s  %-8s","Registrataion Number:",s1.RegistrationNumber);
               System.out.print("\n");
               System.out.printf("%-9s  %-8s","Session: ",getSession(s1.RegistrationNumber));
               System.out.print("\n\n");
               for(int i = 0 ; i < 8 ; i++ )
               {
                 
                 for(int k=0; k< s1.list.size(); k++)
                 {
                   
                    course = new CourseResult();
                   course = s1.list.get(k);
                   int seme = course.semester;
                   System.out.print(seme);
                  if (seme == (1+i))
                   {
                     
                     System.out.print("Semester " + (i+1) + " :\n");
                     System.out.printf("%-20s  %-20s  %-10s  %-10s  %-10s", "ID","Name","CH","Marks","Grades");
                     System.out.print("\n");
                     for(int j=0; j<s1.list.size() ;j++)
                     {
                        DMC = new CourseResult();
                        DMC = s1.list.get(j);
                        ggpa = getSemesterGPA(seme,s1.list);
                        crdhour = getSemesterCreditHours(seme,s1.list);
                        ggpa = ggpa / crdhour;
                        gradee = getGrade(DMC.marks);
                        if(seme == DMC.semester)
                        {
                          System.out.printf("%-20s  %-20s  %-10s  %-10s  %-10s",DMC.CourseId,DMC.CourseTitle,Integer.toString(DMC.CreditHours),Integer.toString(DMC.marks),gradee); 
                          System.out.print("\n");
                        }
                     }
                     gpaa = Double.toString(ggpa);
                     System.out.printf("%60s  %6s","SGPA",gpaa);
                     System.out.print("\n");
                     break;
                   }
                 }
                 
               }
                 ccgpa = getCGPA(s1.list);
                 gpaa = Double.toString(ccgpa);
                 System.out.printf("%60s %6s","CGPA",gpaa);
                 System.out.print("\n");
               break;
        case 8:
                 saveData(s1);
                 saveDMC(s1);
          break;
        case 0:
          
          break;
        default:
          JOptionPane.showMessageDialog( null, "Invalid Input" );
      } // ending switch
      
    }while(option != 0);
    
  } // ending bracket of main
  
} // ending bracket of class;

class CourseResult{
  public String CourseId;
  public String CourseTitle;
  public int CreditHours;
  public int marks;
  public int semester;
}
class Student{
  public String StudentName;
  public String RegistrationNumber;
  public String Degree;
  public List <CourseResult> list = new ArrayList<CourseResult>();
}
